/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myfirstprogram;
import java.io.*; 
/**
 *
 * @author NTC
 */
public class User implements Serializable{
    public String username; 
    private String password; 
    public double balance;      
    public Cart shoppingCart = new Cart(); 

    public User(String username, String password, double balance, Cart shoppingCart) {
        this.username = username;
        this.password = password;
        this.balance = balance;
        this.shoppingCart = shoppingCart;
    }
   

    public String getPassword() {
        return password;
    }
    
    
}
