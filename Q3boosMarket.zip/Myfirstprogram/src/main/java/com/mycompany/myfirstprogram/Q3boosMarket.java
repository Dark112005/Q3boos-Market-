/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.myfirstprogram;

/**
 *
 * @author user
 * +
 */
public class Q3boosMarket {
 public static User [] users; 
    public static String [] promocodes = {"Qa3boos!","Qa3boos?","we want a full mark"}; 

    public static Product [] products = {new flashSale("IPhone",900,0.165),new flashSale("Airpods",185,0.19),new flashSale("TShirt",50,0.6) };
    
    public static void main(String[] args) {
      try {
    new NewJFrame().setVisible(true);
} catch (Exception e) {
    e.printStackTrace(); // Instead of e.getMessage() — shows full stack trace
        }      
    }
}
