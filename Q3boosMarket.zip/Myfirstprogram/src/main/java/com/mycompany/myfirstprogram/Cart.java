/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myfirstprogram;
import java.io.*; 
import java.util.*;
/**
 *
 * @author NTC
 */
public class Cart implements Serializable{
    public ArrayList<Order> orders = new ArrayList<>(); 

    public Cart() {
        
    }
    public int Quantity(){
        int sum = 0; 
        for (int i =0 ; i<orders.size();i ++ )
        {sum+=orders.get(i).quantity; }
    
    return sum;}
    public double payment() {
        double price  =0 ; 
    for (int i = 0 ; i < orders.size();i++ )
        price += orders.get(i).product.get_price() * orders.get(i).quantity; 
    return price; 
    }
}
