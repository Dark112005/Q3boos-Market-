/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myfirstprogram;
import java.io.*;
/**
 *
 * @author NTC
 */
 class Product implements Serializable{
    public String name     ;
    private double price; 
        public double get_price(){
        return price;
        }
    public Product(String name, double price){
    this.name = name ; 
    this.price = price; 
    }
}
 class flashSale extends Product implements Serializable {
     public flashSale(String name, double price,double discount){
         super(name,price);
         this.discount = discount ;
     }
     public double discount ; 
     public double get_price(){
        return super.get_price() *(1-discount);
        }
 } 
